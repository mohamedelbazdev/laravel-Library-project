<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Laravel Project
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2022 <a href="/">ITI Group 1</a>.</strong> All rights
    reserved.
</footer>