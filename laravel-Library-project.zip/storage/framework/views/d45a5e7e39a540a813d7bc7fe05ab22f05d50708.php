

<?php $__env->startSection('title'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Create User</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-9 col-12">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary mb-2 float-right">All Users</a>
                <?php echo Form::open(['route' => 'users.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <div class="form-group">
                    <?php echo Form::text('name', null, ['class' => 'form-control mb-2', 'placeholder' => 'Enter Your Name']); ?>

                    <?php echo Form::email('email', null, ['class' => 'form-control mb-2', 'placeholder' => 'Enter Your Email']); ?>

                    <?php echo Form::password('password', ['class' => 'form-control mb-2','placeholder' => 'Enter Your Password']); ?>


                </div>
                <br>

                <?php echo Form::submit('Add User', ['class' => 'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel-Library-project\resources\views/admin/users/create.blade.php ENDPATH**/ ?>