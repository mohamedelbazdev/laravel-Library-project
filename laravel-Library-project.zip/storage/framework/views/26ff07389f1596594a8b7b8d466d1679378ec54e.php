


<?php $__env->startSection('content'); ?>
    <h1>Create Book</h1>
    <a href="<?php echo e(route('books.index')); ?>" class="btn btn-primary m-2 float-right">All Books</a>
    <div class="container" style="margin-left: 50px;margin-top:20px;">
        <div class="row">
            <div class="col-md-9">
                <?php echo Form::open(['route' => 'books.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <div class="form-group">
                    <label for="name">Book Name</label>
                    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Enter Book Name']); ?>

                    <label for="desc"> Description</label>
                    <?php echo Form::textarea('desc', null, ['class' => 'form-control', 'placeholder' => ' Book Description']); ?>

                    <label for="image"> image</label>
                    <?php echo Form::file('image', null, ['class' => 'form-control', 'placeholder' => 'upload image']); ?>

                    <br>
                    <label for="categories"> Category</label>
                    <?php echo e(Form::select('category_id',$categories, null, ['class'=>'form-control select2','id'=>'category_id'])); ?>

                    <label for="author">Book Author</label>
                    <?php echo Form::text('author', null, ['class' => 'form-control', 'placeholder' => 'Enter Book author']); ?>


                </div>
                <br>

                <?php echo Form::submit('Add Book!', ['class' => 'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel-Library-project\resources\views/admin/books/create.blade.php ENDPATH**/ ?>