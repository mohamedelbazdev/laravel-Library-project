


<?php $__env->startSection('content'); ?>
    <h1>Create Category</h1>
    <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary" style="margin-left: 900px">All Categories</a>
    <div class="container" style="margin-left: 50px;margin-top:20px;">
        <div class="row">
            <div class="col-md-9">
                <?php echo Form::open(['route' => 'category.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <div class="form-group">
                    <label for="exampleInputName">Category</label>
                    <?php echo Form::text('Catname', null, ['class' => 'form-control', 'placeholder' => 'Enter Category Name']); ?>

                </div>
                <br>

                <?php echo Form::submit('Add Category!', ['class' => 'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel-Library-project\resources\views/admin/category/create.blade.php ENDPATH**/ ?>