

<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <div class="box-title">
                <h2>Categories</h2>
            </div>
            <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary m-2 float-right">Add Category</a>

        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>Category</th>
                        <th style="width: 40px">Label</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 25%"><?php echo e($loop->iteration); ?></td>
                            <td style="width: 50%"><?php echo e($category->Catname); ?></td>
                            <td>
                                <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="btn btn-info">Edit</a>
                                <a href='' data-toggle="modal" data-target="#modal_single_del<?php echo e($key); ?>"
                                    class='btn btn-danger m-r-1em'>Remove </a>


                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($key)): ?>
                      <div class="modal" id="modal_single_del<?php echo e($key); ?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">delete confirmation</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    Remove <?php echo e($category->Catname); ?> !!!!
                                </div>
                                <div class="modal-footer">
                                    <form action="<?php echo e(url('/category/' . $category->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>

                                        <div class="not-empty-record">
                                            <button type="submit" class="btn btn-primary">Delete</button>
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">close</button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                </tbody>
                    <?php endif; ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel-Library-project\resources\views/admin/category/index.blade.php ENDPATH**/ ?>