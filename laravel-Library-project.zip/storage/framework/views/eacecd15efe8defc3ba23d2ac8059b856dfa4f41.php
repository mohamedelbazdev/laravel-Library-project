

<?php $__env->startSection('content'); ?>

<div class="box">
        <div class="box-header with-border">
            <div class="box-title">
                <h2>Our Books</h2>
            </div>
            <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary mb-2 float-right" style="margin-left: 900px">Add book</a>

        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Desc</th>
                        <th>Category</th>
                        <th>Author</th>
                        <th style="width: 40px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 25%"><?php echo e($loop->iteration); ?></td>
                            <td style="width: 50%"><?php echo e($book->name); ?></td>
                            <td style="width: 50%"><img style="hight:100px;width:100px;margin:5px;"
                                                src="<?php echo e($book->image); ?>"></td>
                            <td style="width: 50%"><?php echo e($book->desc); ?></td>
                            <td style="width: 50%">

                            <?php echo e(optional($book->categories)->Catname); ?>

                          </td>
                          <td style="width: 50%"><?php echo e($book->author); ?></td>
                            <td>
                                <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-info">Edit</a>
                                <form action="<?php echo e(route('books.destroy',$book->id)); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>

                             <button class="btn default btn-sm bg-red" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>

                                </form>


                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel-Library-project\resources\views/admin/books/index.blade.php ENDPATH**/ ?>